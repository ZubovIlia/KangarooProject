from django.conf.urls.static import static
from django.contrib import admin
from django.template.defaulttags import url
from django.urls import path, include

import liftboards.views
from kangaroo import settings
from liftboards.views import *

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('liftboards.urls'))
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)

#handler404 = pageNotFound
