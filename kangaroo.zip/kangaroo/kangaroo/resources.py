from import_export import resources
from liftboards.models import Liftboard


class LiftboardResource (resources.ModelResource):
    class Meta:
        model = Liftboard
