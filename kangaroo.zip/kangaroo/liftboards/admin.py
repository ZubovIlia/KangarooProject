from django.contrib import admin
from .models import *
from import_export.admin import ImportExportModelAdmin


@admin.register(Street)
class StreetAdmin(admin.ModelAdmin):
    list_display = [
        'id',
        'street',
    ]

    search_fields = [
        'id',
        'street',
    ]

    save_on_top = True
    save_as = False
    pass


@admin.register(Liftboard)
class LiftboardAdmin(ImportExportModelAdmin):
    list_display = [
        'id',
        'street',
        'house_num',
        'count_lifts',
    ]

    search_fields = [
        'id',
        'street',
        'house_num',
        'count_lifts',
    ]

    save_on_top = True
    save_as = False
    pass


@admin.register(Client)
class ClientAdmin(admin.ModelAdmin):
    list_display = [
        'id',
        'name',
        'full_name_manager',
        'phone_num',
        'email'
    ]
    search_fields = [
        'id',
        'name',
        'full_name_manager',
        'phone_num',
        'email'
    ]

    save_on_top = True
    save_as = False


@admin.register(Advertisement)
class AdvertisementAdmin(admin.ModelAdmin):
    list_display = [
        'id',
        'photo_tag',
        'company',
        'placement_date',
        'withdrawal_date',
        'description'
    ]
    search_fields = [
        'id',
        'company',
        'placement_date',
        'withdrawal_date'
    ]

    save_on_top = True
    save_as = False


@admin.register(LiftboardAdvertisement)
class LiftboardAdvertisementAdmin(admin.ModelAdmin):
    list_display = [
        'id',
        'liftboard',
        'advert'
    ]
    search_fields = [
        'id',
        'liftboard',
        'advert'
    ]

    save_on_top = True
    save_as = False
