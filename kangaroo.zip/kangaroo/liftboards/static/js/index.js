let pageName = location.href;
if (pageName[0] === 'http://127.0.0.1:9000') {
    let menuItem = document.getElementById('menu-item2')
    menuItem.setAttribute('style', 'color: #ff7300;')
}
if (pageName[0] === 'http://127.0.0.1:9000/clients/') {
    let menuItem = document.getElementById('menu-item3')
    menuItem.setAttribute('style', 'color: #ff7300;')
}
//$('.open-popup').click(function (e) {
//    e.preventDefault()
//    $('.popup-bg').fadeIn(600);
//})
//$('.close-popup').click(function (e) {
//    $('.popup-bg').fadeOut(600);
//})
$(function () {
    $(window).scroll(function () {
        if ($(this).scrollTop() !== 0) {
            $('#toTop').fadeIn();
        }
        if (($(this).scrollHeight - $(this).scrollTop) === $(this).clientHeight) {
            $('#toTop').fadeOut();
        }
        if ($(this).scrollTop() === 0) {
            $('#toTop').fadeOut();
        }
    });
    $('#toTop').click(function () {
        $('body,html').animate({scrollTop: 0}, 200);
    });
});

//if (menu === 'field-dropdown') {
//    document.querySelector('[data-target=add]').classList.add('popup-active')
//    interval_popup_id = setTimeout(() => {
//        document.querySelector('[data-target=add]').classList.add('open')
//    }, 0)
//}

let interval_dropdown_id
document.querySelectorAll('.dropdown-button').forEach(e => {
    e.addEventListener('click', e => {
        const menu = e.currentTarget.dataset.path
        document.querySelectorAll('.dropdownlist-menu').forEach(e => {
            if (!document.querySelector('[data-target=' + menu + ']').classList.contains('open-dropdown')) {
                document.querySelectorAll('.dropdown-button').forEach(e => {
                    e.setAttribute('style', 'background-color: #f5f5f5; color: black;')
                })
                e.classList.remove('menu-active')
                e.classList.remove('open-dropdown')
                document.querySelector('[data-path=' + menu + ']').setAttribute('style', 'background-color: #ff7300; color: white;')
                document.querySelector('[data-target=' + menu + ']').classList.add('menu-active')
                interval_dropdown_id = setTimeout(() => {
                    document.querySelector('[data-target=' + menu + ']').classList.add('open-dropdown')
                }, 0)
            }
            if (document.querySelector('[data-target=' + menu + ']').classList.contains('open-dropdown')) {
                document.querySelector('[data-path=' + menu + ']').setAttribute('style', 'background-color: #f5f5f5; color: black;')
                clearTimeout(interval_dropdown_id)
                document.querySelector('[data-target=' + menu + ']').classList.remove('menu-active')
                interval_dropdown_id = setTimeout(() => {
                    document.querySelector('[data-target=' + menu + ']').classList.remove('open-dropdown')
                }, 0)
            }
            window.onclick = e => {
                if (e.target === document.querySelector('[data-target=' + menu + ']') || e.target === document.querySelector('[data-path=' + menu + ']')) {
                    return;
                } else {
                    document.querySelector('[data-path=' + menu + ']').setAttribute('style', 'background-color: #f5f5f5; color: black;')
                    document.querySelector('[data-target=' + menu + ']').classList.remove('menu-active')
                    interval_dropdown_id = setTimeout(() => {
                        document.querySelector('[data-target=' + menu + ']').classList.remove('open-dropdown')
                    }, 0)
                }
            }

        })
    })
})

let interval_popup_id
document.querySelectorAll('.button-add').forEach(e => {
    e.addEventListener('click', e => {
        const popup = e.currentTarget.dataset.path
        document.querySelectorAll('.popup-bg').forEach(e => {
            if (!document.querySelector('[data-target=' + popup + ']').classList.contains('open-popup')) {
                document.querySelector('[data-target=' + popup + ']').classList.add('popup-active')
                interval_popup_id = setTimeout(() => {
                    document.querySelector('[data-target=' + popup + ']').classList.add('open-popup')
                }, 0)
            }
        })
    })
})
document.querySelectorAll('.close-cross').forEach(e => {
    e.addEventListener('click', e => {
        const popup = e.currentTarget.dataset.path
        document.querySelectorAll('.popup-bg').forEach(e => {
            if (document.querySelector('[data-target=' + popup + ']').classList.contains('open-popup')) {
                clearTimeout(interval_popup_id)
                document.querySelector('[data-target=' + popup + ']').classList.remove('popup-active')
                interval_popup_id = setTimeout(() => {
                    document.querySelector('[data-target=' + popup + ']').classList.remove('open-popup')
                }, 0)
            }
        })
    })
})
document.querySelectorAll('.close-button').forEach(e => {
    e.addEventListener('click', e => {
        const popup = e.currentTarget.dataset.path
        document.querySelectorAll('.popup-bg').forEach(e => {
            if (document.querySelector('[data-target=' + popup + ']').classList.contains('open-popup')) {
                clearTimeout(interval_popup_id)
                document.querySelector('[data-target=' + popup + ']').classList.remove('popup-active')
                interval_popup_id = setTimeout(() => {
                    document.querySelector('[data-target=' + popup + ']').classList.remove('open-popup')
                }, 0)
            }
        })
    })
})
