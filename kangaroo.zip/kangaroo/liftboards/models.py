from django.db import models
from django.utils.safestring import mark_safe


class Street(models.Model):
    class Meta:
        verbose_name = 'Улица'
        verbose_name_plural = 'Улицы'

    street = models.CharField('Улица',db_index=True, max_length=255)

    def __str__(self):
        return self.street


class Liftboard(models.Model):
    class Meta:
        verbose_name = 'Лифтборд'
        verbose_name_plural = 'Лифтборды'

    street = models.ForeignKey(Street, verbose_name="Улица", on_delete=models.PROTECT)
    house_num = models.CharField('Номер дома', db_index=True, max_length=255)
    count_lifts = models.IntegerField('Количество лифтов', blank=True, null=True)

    def __str__(self):
        return str(self.id)


class Client(models.Model):
    class Meta:
        verbose_name = 'Клиент'
        verbose_name_plural = 'Клиенты'

    name = models.CharField('Наименование', db_index=True, max_length=255)
    full_name_manager = models.CharField('Полное имя заведующего лица', db_index=True, max_length=255)
    phone_num = models.CharField('Контактный номер телефона', db_index=True, max_length=255)
    email = models.CharField('Электронная почта', db_index=True, max_length=255)

    def __str__(self):
        return self.name


def upload_to_advert(instance, filename):
    return 'liftboards/images/adverts/%s' % filename


class Advertisement(models.Model):
    class Meta:
        verbose_name = 'Рекламное объявление'
        verbose_name_plural = 'Рекламные объявления'

    company = models.ForeignKey(Client, verbose_name="Предприятие", on_delete=models.PROTECT)

    photo = models.ImageField('Фото', upload_to=upload_to_advert)
    placement_date = models.DateField('Дата размещения', db_index=True)
    withdrawal_date = models.DateField('Дата снятия', db_index=True, blank=True, null=True)
    description = models.TextField('Описание', blank=True, null=True)

    def __str__(self):
        return str(self.id)

    def photo_tag(self):
        return mark_safe('<img src="%s" width="50" height="100" />' % self.photo.url)

    photo_tag.short_description = 'Фото рекламы'


class LiftboardAdvertisement(models.Model):
    class Meta:
        verbose_name = 'Состав лифтбордов'

    liftboard = models.ForeignKey(Liftboard, verbose_name="Лифтборд", on_delete=models.PROTECT)
    advert = models.ForeignKey(Advertisement, verbose_name="Рекламное объявление", on_delete=models.PROTECT)

    def __str__(self):
        return str(self.id)
