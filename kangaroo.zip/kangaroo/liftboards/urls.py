from .views import *
from django.urls import path

urlpatterns = [
    path('', liftboards, name='liftboards'),
    path('adverts_list/<int:liftboard_id>', adverts_list, name='adverts_list'),
    path('clients/', clients_list, name='clients_list')
]