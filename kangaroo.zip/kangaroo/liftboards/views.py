from django.http import HttpResponse, HttpResponseNotFound
from django.shortcuts import render
from django_filters.rest_framework import DjangoFilterBackend

from kangaroo.resources import LiftboardResource
from liftboards import templates
from django.core.paginator import Paginator
from django.shortcuts import render, get_object_or_404
from liftboards.models import *
from .forms import *

#def pageNotFound(request):
    #return HttpResponseNotFound("Page Not Found. Страница не найдена")


def liftboards(request):
    streets = Street.objects.all()
    error = ''
    if request.method == 'POST':
        error = 0
        form = LiftboardForm(request.POST)
        for street in streets:
            if street.street == form.street:
                form.street = street.id
        if form.is_valid():
            form.save()
        else:
            error = 1
    form = LiftboardForm()
    liftboards = Liftboard.objects.all().order_by('id')
    search = request.GET.get('search')
    filtering = request.GET.get('filtering')
    order_by = request.GET.get('order_by')
    if search:
        liftboards = liftboards.filter(street__liftboard__house_num__icontains=search)
    if filtering:
        if filtering == "default":
            liftboards = Liftboard.objects.all().order_by('id')
        else:
            liftboards = liftboards.filter(street__street__icontains=filtering)
    if order_by:
        if order_by == "default":
            liftboards = liftboards.order_by('id')
        if order_by == "asc":
            liftboards = liftboards.order_by('count_lifts')
        if order_by == "desc":
            liftboards = liftboards.order_by('-count_lifts')
    paginator = Paginator(liftboards, 4)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    main_count = liftboards.count()
    lifts_adverts = LiftboardAdvertisement.objects.all()
    adverts = Advertisement.objects.all()
    streets = Street.objects.all()
    data = {
        'liftboards': page_obj,
        'main_count': main_count,
        'lifts_adverts': lifts_adverts,
        'adverts': adverts,
        'streets': streets,
        'form': form
    }
    return render(request, 'liftboards/liftboardsList.html', data)


def adverts_list(request, liftboard_id):
    error = ''
    if request.method == 'POST':
        error = 0
        form = AdvertForm(request.POST)
        if form.is_valid():
            form.save()
        else:
            error = 1
    form = AdvertForm()
    lifts_adverts = LiftboardAdvertisement.objects.all()
    clients = Client.objects.all()
    adverts = []
    for lift_advert in lifts_adverts:
        if(lift_advert.liftboard_id == liftboard_id):
            adverts.append(lift_advert.advert)
    paginator = Paginator(adverts, 2)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    data = {
        'adverts': page_obj,
        'clients': clients,
        'form': form
    }
    return render(request, 'liftboards/advertsList.html', data)


def clients_list(request):
    error = ''
    if request.method == 'POST':
        error = 0
        form = ClientForm(request.POST)
        if form.is_valid():
            form.save()
        else:
            error = 1
    form = ClientForm()

    clients = Client.objects.all()
    paginator = Paginator(clients, 3)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    data = {
        'clients': page_obj,
        'form': form,
        'error': error
    }
    return render(request, 'liftboards/clientsList.html', data)


def export(request):
    liftboard_resource = LiftboardResource()
    dataset = liftboard_resource.export()
    response = HttpResponse(dataset.csv, content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="liftboard.csv"'
    return response