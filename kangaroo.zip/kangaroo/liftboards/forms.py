from .models import *
from django.forms import ModelForm, TextInput, Textarea, DateInput, NumberInput


class ClientForm(ModelForm):
    class Meta:
        model = Client
        fields = ['name', 'full_name_manager', 'phone_num', 'email']

        widgets = {
            "name": TextInput(attrs={
                'class': 'field-block',
                'placeholder': 'Название компании',
            }),
            "full_name_manager": TextInput(attrs={
                'class': 'field-block',
                'placeholder': 'Полное имя заведующего лица',
            }),
            "phone_num": TextInput(attrs={
                'class': 'field-block',
                'placeholder': 'Контактный номер телефона',
            }),
            "email": TextInput(attrs={
                'class': 'field-block',
                'placeholder': 'Электронная почта',
            })
        }


class AdvertForm(ModelForm):
    class Meta:
        model = Advertisement
        fields = ['company', 'photo', 'placement_date', 'description']

        widgets = {
            "company": TextInput(attrs={
                'class': 'field-block',
                'placeholder': 'Название компании',
            }),
            "photo": TextInput(attrs={
                'class': 'field-block',
                'placeholder': 'Фото',
            }),
            "placement_date": DateInput(attrs={
                'class': 'field-block',
                'placeholder': 'Дата размещения',
            }),
            "description": Textarea(attrs={
                'class': 'field-block',
                'style': 'height: 100px; max-height: 150px; min-height: 40px; padding: 7px 20px;',
                'placeholder': 'Описание'
            })
        }


class LiftboardForm(ModelForm):
    class Meta:
        model = Liftboard
        fields = ['street', 'house_num', 'count_lifts']

        widgets = {
            "street": TextInput(attrs={
                'class': 'field-block',
                'placeholder': 'Улица',
            }),
            "house_num": NumberInput(attrs={
                'class': 'field-block',
                'placeholder': 'Номер дома',
            }),
            "count_lifts": NumberInput(attrs={
                'class': 'field-block',
                'placeholder': 'Количество лифтов',
            })
        }

